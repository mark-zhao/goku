/*
Package NAME manages and retrieves RESOURCE in the OpenStack SERVICE Service.

Example to List RESOURCE

Example to Create a RESOURCE

Example to Update a RESOURCE

Example to Delete a RESOURCE

*/
package RESOURCE
