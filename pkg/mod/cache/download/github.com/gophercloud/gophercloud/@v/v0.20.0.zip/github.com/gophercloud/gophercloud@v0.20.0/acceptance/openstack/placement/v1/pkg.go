// Package placement contains acceptance tests for the Openstack Placement service.
package v1
